// Keeps the toolbar badge in sync and adds a right-click "Add to to-do" option.

async function getTasks() {
  const { tasks = [] } = await chrome.storage.sync.get("tasks");
  return tasks;
}

async function updateBadge(tasks) {
  const left = (tasks || (await getTasks())).filter((t) => !t.done).length;
  await chrome.action.setBadgeBackgroundColor({ color: "#2F5BFF" });
  await chrome.action.setBadgeText({ text: left ? String(left) : "" });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "add-todo",
    title: "Add \"%s\" to to-do",
    contexts: ["selection"],
  });
  updateBadge();
});

chrome.runtime.onStartup.addListener(() => updateBadge());

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== "add-todo" || !info.selectionText) return;
  const tasks = await getTasks();
  tasks.unshift({
    id: crypto.randomUUID(),
    text: info.selectionText.trim().slice(0, 300),
    done: false,
    created: Date.now(),
  });
  await chrome.storage.sync.set({ tasks });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && changes.tasks) updateBadge(changes.tasks.newValue || []);
});
