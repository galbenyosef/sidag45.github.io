const form = document.getElementById("add-form");
const input = document.getElementById("new-task");
const list = document.getElementById("list");
const tpl = document.getElementById("item-tpl");
const countEl = document.getElementById("count");
const emptyEl = document.getElementById("empty");
const footer = document.getElementById("footer");
const clearBtn = document.getElementById("clear-done");

let tasks = [];

async function load() {
  const data = await chrome.storage.sync.get("tasks");
  tasks = data.tasks || [];
  render();
}

function save() {
  return chrome.storage.sync.set({ tasks });
}

function render() {
  list.textContent = "";
  // Unfinished first, then finished; newest first within each group.
  const sorted = [...tasks].sort((a, b) => a.done - b.done || b.created - a.created);

  for (const task of sorted) {
    const li = tpl.content.firstElementChild.cloneNode(true);
    li.dataset.id = task.id;
    li.classList.toggle("done", task.done);
    const box = li.querySelector("input");
    box.checked = task.done;
    box.setAttribute("aria-label", `Mark "${task.text}" as ${task.done ? "not done" : "done"}`);
    li.querySelector(".text").textContent = task.text;
    list.appendChild(li);
  }

  const left = tasks.filter((t) => !t.done).length;
  const doneCount = tasks.length - left;
  countEl.textContent = tasks.length ? `${left} left` : "";
  emptyEl.hidden = tasks.length > 0;
  footer.hidden = tasks.length === 0;
  clearBtn.disabled = doneCount === 0;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  tasks.push({ id: crypto.randomUUID(), text, done: false, created: Date.now() });
  input.value = "";
  render();
  await save();
});

list.addEventListener("change", async (e) => {
  if (e.target.type !== "checkbox") return;
  const task = tasks.find((t) => t.id === e.target.closest(".item").dataset.id);
  task.done = e.target.checked;
  render();
  await save();
});

list.addEventListener("click", async (e) => {
  if (!e.target.classList.contains("delete")) return;
  const id = e.target.closest(".item").dataset.id;
  tasks = tasks.filter((t) => t.id !== id);
  render();
  await save();
});

// Double-click to edit; Enter saves, Escape cancels, emptying it deletes the task.
list.addEventListener("dblclick", (e) => {
  const span = e.target.closest(".text");
  if (!span) return;
  const id = span.closest(".item").dataset.id;
  const original = span.textContent;
  span.contentEditable = "true";
  span.focus();
  document.getSelection().selectAllChildren(span);

  const finish = async (commit) => {
    span.removeEventListener("keydown", onKey);
    span.removeEventListener("blur", onBlur);
    span.contentEditable = "false";
    const text = span.textContent.trim();
    if (!commit || text === original) return render();
    tasks = text
      ? tasks.map((t) => (t.id === id ? { ...t, text: text.slice(0, 300) } : t))
      : tasks.filter((t) => t.id !== id);
    render();
    await save();
  };
  const onKey = (ev) => {
    if (ev.key === "Enter") { ev.preventDefault(); finish(true); }
    if (ev.key === "Escape") { ev.preventDefault(); finish(false); }
  };
  const onBlur = () => finish(true);
  span.addEventListener("keydown", onKey);
  span.addEventListener("blur", onBlur);
});

clearBtn.addEventListener("click", async () => {
  tasks = tasks.filter((t) => !t.done);
  render();
  await save();
});

// Pick up tasks added from the right-click menu while the popup is open.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && changes.tasks) {
    tasks = changes.tasks.newValue || [];
    if (document.activeElement?.contentEditable !== "true") render();
  }
});

load();
